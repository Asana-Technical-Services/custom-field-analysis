"""uploads projects to Asana"""

__version__ = "0.1"

import os
import asyncio
import aiohttp
import sys
from .menu import menu
from .asanaUtils.projectFunctions import (
    create_projects,
    add_projects_to_portfolio,
    set_project_custom_fields,
    set_project_statuses,
)

##############################################
##              Main Function               ##
##  orchestrates all other functionality    ##
##############################################


async def projectupload():
    """an async function to upload projects from a CSV to a portfolio in Asana"""

    ## create the client session with aiohttp - this library allows us to send multiple API requests at once in conjunction with asyncio
    async with aiohttp.ClientSession() as session:
        [
            team,
            project_inputs,
            project_statuses,
            portfolio,
            token,
        ] = await menu(session)

        print("Creating projects...")
        projects = await create_projects(project_inputs, team, session, token)

        print("Adding projects to the portfolio...")
        await add_projects_to_portfolio(projects, portfolio, session, token)

        print("Setting custom field values...")

        # each of these steps is an async function - we can do them in parallel. first we get the tasks they create
        set_custom_fields_task = set_project_custom_fields(projects, session, token)

        set_project_statuses_task = set_project_statuses(
            projects, project_statuses, session, token
        )

        # Gather both of the above tasks and wait for them both to finish
        await asyncio.gather(set_custom_fields_task, set_project_statuses_task)

        print(
            f"Complete! check out the results at https://app.asana.com/0/{portfolio['gid']}/overview"
        )

    return


## main function which is targeted by the CLI command
def main():
    """runs the project upload function asynchronously"""

    try:
        asyncio.run(projectupload())
    except KeyboardInterrupt:
        print("\nInterrupted - goodbye")
        try:
            sys.exit(0)
        except SystemExit:
            os._exit(0)


## if this file is run directly via Python:
if __name__ == "__main__":
    try:
        asyncio.run(projectupload())
    except KeyboardInterrupt:
        print("\nInterrupted - goodbye")
        try:
            sys.exit(0)
        except SystemExit:
            os._exit(0)
