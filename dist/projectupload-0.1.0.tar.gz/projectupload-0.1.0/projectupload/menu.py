import sys
import csv
from .asanaUtils.client import asana_client
from .asanaUtils.projectFunctions import map_project_fields, map_project_status

"""
input menu + associated functions

used for gathering all user inputs, mapping fields, and verifying that mapping before proceeding.
"""


async def menu(session):
    """
    Collect user inputs of: Personal Access Token, portfolio link, team link, and CSV file.
    provides back the team, mapped project data, necessary project statuses, attribute mapping, portfolio, and the user's Personal Access Token
        project_data,
        project_statuses,
        portfolio,
        session,
        token,
    """

    # get access token
    token = input("paste your personal access account token: ")

    # test the token to ensure it works
    user = await asana_client(
        **{"method": "GET", "url": "/users/me", "session": session, "token": token}
    )
    if not user:
        sys.exit("invalid account token")

    # get link to portfolio and split it to get the Global ID
    portfolio_link = input(
        "paste a link to the portfolio (https://app.asana.com/0/portfolio/12345/list): "
    )

    ## split the link to get the portfolio GID number from the URL
    portfolio_gid = portfolio_link.split("/")[-2]

    # try getting the portfolio from Asana to make sure it exists and we can access it
    portfolio = await asana_client(
        **{
            "method": "GET",
            "url": f"/portfolios/{portfolio_gid}",
            "session": session,
            "token": token,
        }
    )

    if not portfolio:
        sys.exit(
            "could not get portfolio or it does not exist. check that you have access to it"
        )

    # get any projects already in the portfolio
    portfolio_items = await asana_client(
        **{
            "method": "GET",
            "url": f"/portfolios/{portfolio_gid}/items",
            "session": session,
            "token": token,
        }
    )

    # count how many projects are already there so we can avoid going over the limit of projects in a portfolio
    portfolio_length = len(portfolio_items)

    # now get the custom fields in the portfolio. This is a dictionary with the CF name as the key.
    custom_fields = get_custom_fields_from_portfolio(portfolio)

    # create a list of all the custom field names
    custom_field_string = ""
    for field_name in custom_fields.keys():
        custom_field_string += field_name + "\n"

    # print to confirm to the user on which portfolio we're using, and the custom fields we found
    print(f"Using portfolio {portfolio['name']} with custom fields:")
    print(custom_field_string)

    # get the team link from the user
    team_link = input(
        "paste a link to the team you'd like the new projects to be created in: (https://app.asana.com/0/12345/overview): "
    )

    # get the team ID from the url
    team_gid = team_link.split("/")[-2]

    # fetch the team data from Asana
    team = await asana_client(
        **{
            "method": "GET",
            "url": f"/teams/{team_gid}",
            "session": session,
            "token": token,
        }
    )

    # verify that the team exists, and print to the user
    if not team:
        sys.exit(
            "\n could not get team or it does not exist. check that you have access to it"
        )

    print(f"\n ok, we'll use the team: {team['name']}")

    # get the path the CSV file
    file_path = input(
        "\n drag and drop your file to this terminal or enter the file path to the CSV file of projects:"
    )

    # sometimes there are additional '\' characters added, or spaces around the path - remove those:
    file_path = file_path.replace("\\", "").strip()

    # prepare a list for all projects in the CSV
    project_inputs = []

    # set the CSV parser arguments
    dialect = csv.excel
    dialect.delimiter = ","
    ## get all projects from the CSV file
    with open(file_path, mode="r", encoding="utf-8-sig") as f:
        project_file = csv.DictReader(f, dialect="excel", **{"skipinitialspace": True})
        for item in project_file:
            project_inputs.append(item)

    if len(project_inputs) < 1:
        sys.exit("no projects found in file")

    # get the input fields from the CSV header - as defined from keys of the dictionary
    csv_headers = project_inputs[0].keys()

    # map the names of the CSV headers to the custom fields available in the portfolio
    # returns a mapping of attributes from csv header -> custom field object
    [attribute_mapping, has_name] = map_csv_to_portfolio(csv_headers, custom_fields)

    if not "status" in csv_headers and not "Status" in csv_headers:
        print("NOT FOUND IN CSV: Status")

    # the function
    if not has_name:
        sys.exit(
            "ERR: name was not found in the CSV, cannot create projects without a name! \n exiting."
        )

    print("\n")
    # keep track of the project row number so that we can reference which project had a mapping error, if there is any
    project_row_number = 2

    # new list to hold the mapped projects
    project_data = []

    # status updates need to be created separately, so we have a separate list for them
    project_statuses = []

    for project in project_inputs:
        new_project = map_project_fields(project, attribute_mapping, project_row_number)

        if "name" in new_project and new_project["name"] != "":
            project_data.append(new_project)
            project_statuses.append(map_project_status(project))
        else:
            print(
                f"WARN: name not found for project in row {project_row_number} - this project will not be created"
            )
        # inc
        project_row_number += 1

    # quit if the portfolio will be too big.
    if (portfolio_length + len(project_data)) >= 250:
        print(
            f"This portfolio has {portfolio_length} projects and this CSV has {len(project_data)} rows."
        )
        sys.exit(
            "Portfolios can only contain 250 projects, and uploading this CSV will hit that limit. - please reduce the size or use a different portfolio"
        )

    confirmation = input("proceed? (Y/n)")

    if confirmation.lower() == "n":
        sys.exit("goodbye!")

    return [
        team,
        project_data,
        project_statuses,
        portfolio,
        token,
    ]


def get_custom_fields_from_portfolio(portfolio):
    """create a dictionary of custom fields from the Asana portfolio object"""

    custom_fields = {}
    # create dictionary which maps the name of the custom field from the portfolio to the field metadata
    # custom fields are defined in array of "custom field settings" which each contain a custom field object.
    for field_setting in portfolio["custom_field_settings"]:

        field_name = field_setting["custom_field"]["name"].lower()
        custom_fields[field_name] = field_setting["custom_field"]

        # if the custom field is an enum or a multi-enum,
        # take the array of enum options and turn it into a dict for easier use later
        if "enum" in field_setting["custom_field"]["type"]:
            enum_dict = {}
            # for every enum option in the array
            for i in range(0, len(field_setting["custom_field"]["enum_options"])):

                # get the enum option
                enum_option = field_setting["custom_field"]["enum_options"][i]

                # use its name as the key, and set the value as the complete enum object
                enum_dict[enum_option["name"].lower()] = enum_option

            # add the enum dictionary to the custom field object for use later
            custom_fields[field_name]["enum_dict"] = enum_dict

    return custom_fields


def map_csv_to_portfolio(csv_headers, custom_fields):
    attribute_mapping = {}

    has_name = False

    # map headers from the CSV (input custom fields) to the custom fields in the portfolio (custom fields)
    print("attribute mapping: \ncsv header \t => \t Asana project field ")
    for input_field in csv_headers:
        # account for standard fields:
        if input_field.lower() == "name" or input_field.lower() == "project name":
            attribute_mapping[input_field] = "name"
            has_name = True
            print(f"{input_field}\t => \t name")

        elif input_field.lower() == "status":
            ## we don't add this to the attribute mapping since we handle this separately later
            print(f"{input_field}\t => \t Status")

        elif input_field.lower() == "owner" or input_field.lower() == "project owner":
            attribute_mapping[input_field] = "owner"
            print(f"{input_field}\t => \t owner")

        elif input_field.lower() in ["date", "due date", "end date", "end on", "end"]:
            attribute_mapping[input_field] = "due_date"
            print(f"{input_field}\t => \t due date")

        elif input_field.lower() in [
            "start on",
            "start date",
            "start",
            "begin",
            "begin on",
        ]:
            attribute_mapping[input_field] = "start_on"
            print(f"{input_field}\t => \t start on")

        else:
            for key in custom_fields.keys():
                if key.lower() == input_field.lower():
                    attribute_mapping[input_field] = custom_fields.pop(key)
                    print(
                        f"{input_field}\t => \t {attribute_mapping[input_field]['name']}"
                    )
                    break

            if input_field not in attribute_mapping.keys():
                print(f"{input_field}\t => \t NO MAPPING FOUND IN PORTFOLIO")

    for key in custom_fields:
        print(f"NOT FOUND IN CSV: {key}")

    return [attribute_mapping, has_name]
