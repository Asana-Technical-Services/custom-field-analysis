# Project Upload script

This python script is used to upload a CSV of projects to a portfolio with custom fields set.

Projects created by this script initially will contain no tasks, as they are primarily for creating base tracking at the portfolio level.

## Requirements

This script is written using Python 3.8, though it should be compatible with most 3.x versions of python.

check your version of python locally installed with the command:

```
python -V
```

If you need to install a newer version of python, you can do so at https://www.python.org/downloads/

_Be sure to install certificates (by running the appropriate script in the python folder) if you download a new version of python_

## Installing the script

This python script has been packaged into an installable package, which can be found under the `/dist` folder. both a tar.gz and .whl file can be found. It's recommended to use the .whl file as it is generally more consistent.

To install, run the python installer `pip` with the path to the whl file. you can usually drag and drop a file into the command line terminal to get the path

```
pip install /path/to/dist/projectupload.whl
```

Once installed, the script can be run via

```
projectupload
```

On installation, you may recieve a warning like:

```
WARNING: The script projectupload is installed in '/Library/Frameworks/python.framework/Versions/3.9/bin' which is not on PATH
```

To add that directory to path, simply run the following command with your path from above filled in:

```
export PATH=$PATH:your/path/here
```

e.g. `export PATH=$PATH:/Library/Frameworks/python.framework/Versions/3.9/bin`

This should allow you to run this script from the single `projectupload` command

Alternatively, a 'runprojectupload.py' file has been provided in the base directory to run the script directly via

```
python path/to/runprojectupload.py
```

## Operation

Run the script using

```
projectupload
```

or alternatively:

```
python projectupload.py
```

The script interactively asks for 4 arguments:

- a personal access token (PAT)
- a link to the portfolio where the projects should be added
- a link to the team where there projects should be added
- the path in your filesystem to the CSV you'd like to upload

Personal access tokens are how the script authenticates with asana to create these projects as your Asana user. To get one, follow this Asana guide article https://asana.com/guide/help/api/api

The script will attempt to match custom fields from the portfolio with the header row of the CSV file, and will confirm the mapping before proceeding. Along with the custom fields in the portfolio, the script will also match:

- name
- owner
- start date (maps to date range input)
- end date
- status

The project date range seen in the product is split into two input fields in the CSV for clarity.

It will flag any fields that could not be mapped, or are in an invalid format. Note that the names in the CSV must match the field names exactly, though they are not case sensitive.

Note that Status is not actually a field but an indicator of the latest status update posted to that project. In order to map it, the project will post and update titled "Initial Status"

## Input CSV format

Tthe input CSV is expected to be in comma(,)-delimited, UTF-8 format.

All dates should be in yyyy-mm-dd format (2022-12-30). This is a field date format setting that can be set in excel

If there is a multiselect field with options "1" and "2", they should be encapsulated in double quotes such as "1,2". Exporting from excel should do this for you, but it is worth verifying.

The project owner field in Asana is a reference to an Asana user, and so it must be a valid email address of a user in the your Asana organization.

## Rate Limits

Due to the high volume of API calls this script makes, it may sometimes hit rate limits and need to set some delay between its API calls. The exact amount of delay will be printed to the console. Because the script will be running many calls in parallel, this message may print multiple times, once for each API call that was blocked due to rate limiting. These wait times will not be additive, since the calls are running in parallel. Once the wait duration is up, each API call will be retried with increasing delay until it succeeds. After ~10 tries (which would take almost 3 minutes of attempts) the individual api call will be canceled.

## Code Structure

The package is written as a basic interactive script, coordinated by the main function in projectupload.py

The codebase is laid out as follows:

```
├── README.md
├── dist/
├── projectupload
│   ├── asanaUtils
│   │   ├── client.py
│   │   └── projectFunctions.py
│   ├── menu.py
│   └── projectupload.py
├── projectupload.egg-info/
├── pyproject.toml
├── requirements.txt
├── runprojectupload.py
├── setup.cfg
└── setup.py
```

All source code is contained within the `projectupload` directory. The projectupload function within the projectupload.py file coordinates all other functionality of the script.

The menu.py file contains the menu and a few helper functions to gather user input and map the CSV to the portfolio fields.

The asanaUtils directory contains a client.py file, which handles formatting and sending API calls, along with handling rate limits, and a projectFunctions.py file containing helper functions to create projects, set their custom fields and, update their statuses.

The `dist` and `projectupload.egg-info` directories contain build information generated when packaging the project.

## Testing and Re-building a new version of the package

To test and run the script code directly, you can run a file in the top of this directory which imports the package and runs it.

```
python runprojectupload.py
```

To re-build the packages in the `dist` folder (after making changes to the script, for example), you'll need the `setuptools` package (installed via `pip install setuptools`). Then while in this directory, run:

```
python -m build
```

Changes to the configuration, name, or version, should primarily be made through the setup.cfg file.
